from __future__ import print_function
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import pandas as pd
import json
SCOPE = ['https://www.googleapis.com/auth/spreadsheets ' + "https://www.googleapis.com/auth/drive.file " + "https://www.googleapis.com/auth/drive"]
SECRETS_FILE = "401k Investment Survey-e18c0a1e52ea.json"
SPREADSHEET = "401k Investment Survey (Responses)"
json_key = json.load(open(SECRETS_FILE))
credentials = ServiceAccountCredentials.from_json_keyfile_name('401k Investment Survey-e18c0a1e52ea.json', SCOPE) 
{
"private_key_id": "e18c0a1e52ea0aab1efa03fd1755a231425d3c04",
"private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCqj+p3p9CWU2bg\neV69WuWcsSLCUu5RCa14zvLNmzCj1/ud8ZlX2l/eyaykSFHuKwR3shwdZpav7akf\nYH9dTOWArxX0CbKh7QXhR1+nFYzDWITKCLc3EPZ+kJLlxyZn0nkvQWa31kpo33j6\n1YtG8fu2UOSl855ogdl8yUMoECoIwuCKoXZ4r4Hrg+eY1c32K1nKFjld0u+ZCKvj\n0ENh5vftM7qUEbbjVYfk+wJvQ8PqhJVHxuqynLuxv+Ayzovt8wpP3O73z1ek3U+D\n9u1CnurtH324T/sdnlb7nMYbN19at5WxQYj+kYNkxZaJ0hdtjsMbAouf1kLBrilw\n7Te61GvTAgMBAAECggEAF4yMQl4Mqhy0yQxo3LsGlcZNNshNeCneZh4onuOs6QpC\nhtGbKuqPLwroR7xmd3w//yi7wgFuj7bAEYF4xFCAJW7HGK0YGUxI8gwxNDgA+d2o\nY96lMTip19qtNYV0E4SXT8N3Y612E5m7MeK2+qIhb1Am6ZTDy8kV1qlRGOB2dUP9\nGLNn84C4n7xhgrZ4vu8Us2OzrdcrU2jYlv6gCl1EUAswSFfWQItWP8O40rmYo5ku\nQk5czUFcxJOm2VUIDv1qqhId4J2L1MVTsa/RtJgWTcJmSVyOIz+JI0bdYbzPdWCk\nZ8REF9oVuiSuvSMF51NdTVy5XSjScsJC/DhEZdHxpQKBgQDTuM6IpPGX/8g7upFa\nqGBdVwwhWWA05rLvxiDrnln5FFql1LWURszB7Vgi1zjO/fbmSp5Bm6h+tvHEsQm3\nJVmjnvdO0Bn+nqZs+rpNwJhKYHsKf80O3jDjQagsjOwZOmMv94UJDX4PkIlRN6Er\naGrFBB6SoP+swt6gXcOIhD2ZDwKBgQDOO36SeZIHgFYquhF7y00RoHNopfisR5Wa\nn20GgnTUQkOMdtDdf1zbGTvYfn9W80OFKNo0K3JrdxR1IujD3UgHbqhRfzB52SBs\nDILgB71aktGElarQhvV7roaC4H2vSELOTzZQmxsTLVuURmLMsOTFPpG8T/0PWf1j\nzPo4pzlY/QKBgC6CsbRo773hbd5ZLOdKh+jZX4vP84eLipGL59166u8B3qwBX2ZU\na1TKzArTVuJ5/gw3Ji7pgAleLRx1e9nk9Z0xJckFhEBgH9Ve+yBrh8kHCuCSlLyI\naRrzaHto9dDQ98sox+vmL+RBbzkNTHWZuaLQNdsmTSRpprh6AKNz0YhXAoGBAIjy\n+RpLoK1ai93TsciDOKp74iecD4ZYAwCq3bt05iAN4M1mGUz9Rqw4FYWueuFCqZPD\njSMXtuOmL++ZPvjR+QL2eM+lpotDpEQcCsy6VwPOe1OQD95pwJphSvGeIdhEJBjc\ngTUFyvTxKd9M3k8PKNvSsPRcKbAIEjwz4fW9FlgBAoGAQsisbJlZR+b6dN4IMunn\nT5q+vh+vr+17ep5A4WNeF6latlWWP7RgHCU3xDaDhaoCYIB2/XVqpCqdZJCK9shI\nDGOH3dy6Fzo9KjPX6WzCHauSLKgPM5qX9T+42E0MFxxoNLcsLmT+ClkaZg+GLj5U\nPDiJpuPEtZIbBep+KU/+2hU=\n-----END PRIVATE KEY-----\n",
"client_email": "credentials@k-investment-survey.iam.gserviceaccount.com",
"client_id": "103003831446869803963",
"auth_uri": "https://accounts.google.com/o/oauth2/auth",
"token_uri": "https://oauth2.googleapis.com/token",
"auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
"client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/credentials%40k-investment-survey.iam.gserviceaccount.com"
}
gc = gspread.authorize(credentials)
#print("The following sheets are available")
#for sheet in gc.openall():
#    print("{} - {}".format(sheet.title, sheet.id))
workbook = gc.open(SPREADSHEET)
sheet = workbook.sheet1
data = pd.DataFrame(sheet.get_all_records())
column_names = {'Timestamp': 'timestamp',
                'When do you expect to begin withdrawing money from your investment account?': 'withdraw_begin',
                'Once you begin withdrawing money from you investment account, how long do you expect the withdrawals to last?': 'withdraw_length',
                'Historically, investors who have received high level long-term average returns have experienced greater fluctuations in their account values than investors in more conservative investments. Considering the above, which statement best describes your investment objectives?': 'investment_objectives',
                'Suppose you owned a well-diversified portfolio that declined 20% in a short period of time in a volatile market environment. Assuming you still have 10 years until you begin taking withdrawals, what, if any, action would you take?': 'portfolio_action',
                'How do you feel about this statement – I am comfortable with the investments that may frequently experience large declines in value if there is a potential for higher returns?': 'risk_comfort',
                }
data.rename(columns=column_names, inplace=True)
#print(data.head())
points = { 
'a. Less than 1 year':0,
'b. 1 to 2 years':1,
'c. 3 to 4 years':3,
'd. 5 to 7 years':7,
'e. 8 to 10 years':9,
'f. 11 years or more':11,

'a. I plan to take a lump sum distribution':0,
'b. 1 to 4 years':2,
'c. 5 to 7 years':4,
'd. 8 to 10 years':5,
'e. 11 years or more':6,

'a. Protect the value of my account':0,
'b. Keep risk to a minimum':5,
'c. Balance risk and return':10,
'd. Maximize long-term investment returns':15,

'a. I would not change my portfolio': 15,
'b. I would wait at least a year':10,
'c. I would wait at least three months':5,
'd. I would make a change immediately':0,

'a. Agree':15,
'b. Neither':8,
'c. Disagree':0
}
user_number = int(input("Enter the desired survey response number: "))
print ('User #' + str(user_number))
user_id = user_number + 1
print ("Your survey response answers were:")
print (sheet.row_values(user_id))
point_total = points[sheet.cell(user_id, 2).value] + points[sheet.cell(user_id, 3).value] + points[sheet.cell(user_id, 4).value] + points[sheet.cell(user_id, 5).value] + points[sheet.cell(user_id, 6).value]
print ("Your point total is " + str(point_total))
if point_total >= 0 and point_total <= 6:
  plan = 'Conservative Income. You should allocate about 30% of your funds into Equities, 50% into Fixed Income, and 20% into Stable/Money Market.'
if point_total >= 7 and point_total <=16:
  plan = 'Income. You should allocate about 40% of your funds into Equities, 40% into Fixed Income, and 20% into Stable/Money Market.'
if point_total >=17 and point_total <=28:
  plan = 'Conservative Growth. You should allocate about 50% of your funds into Equities, 35% into Fixed Income, and 15% into Stable/Money Market.'
if point_total >=29 and point_total <=42:
  plan = 'Moderate Growth. You should allocate about 65% of your funds into Equities, 25% into Fixed Income, and 10% into Stable/Money Market.'
if point_total >=43 and point_total <=54:
  plan = 'Growth. You should allocate about 75% of your funds into Equities, 25% into Fixed Income, and 0% into Stable/Money Market.'
if point_total >=55 and point_total <=62:
  plan = 'Growth. You should allocate about 90% of your funds into Equities, 10% into Fixed Income, and 0% into Stable/Money Market.'

print ('Based on your point total, you are looking for ' + str(plan))